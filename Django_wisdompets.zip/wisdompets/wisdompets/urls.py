
from django.contrib import admin
from django.conf.urls import url

from adoption import views

urlpatterns = [
    url('admin/', admin.site.urls),
	url(r'^$',views.home,name='home'),
	url(r'^pets/(\d+)/',views.pet_detail,name='pet_detail'),
]
